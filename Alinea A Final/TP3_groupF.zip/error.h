#ifndef ERROR
#define ERROR

#include "point.h"


void errorMessageMem(char* s);
void errorMessageOut(char* s, Point* p);
void errorMessageMap(char* s);
#endif
