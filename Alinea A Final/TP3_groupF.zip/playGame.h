#ifndef PLAYGAME
#define PLAYGAME

#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
#include "game.h"
#include "interface.h"
#include <unistd.h> 
#include "clearMemory.h"

#endif

 

