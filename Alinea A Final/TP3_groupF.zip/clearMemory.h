#ifndef CLEARMEMORY
#define CLEARMEMORY


#include "player.h"
#include "map.h"

void clearMemory(Player* p1, int size);
void clearMemoryMap(Map* p1,int size);
#endif
