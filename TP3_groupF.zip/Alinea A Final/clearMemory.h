#ifndef CLEARMEMORY
#define CLEARMEMORY

#include "player.h"

void clearMemory(Player *p1);
#endif
