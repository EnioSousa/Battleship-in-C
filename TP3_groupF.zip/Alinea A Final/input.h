#ifndef INPUT
#define INPUT

#define maxNameSize 60 // maximum characters for nickname

/*-----------------------Numbers input-----------------------------*/
int inputCheck();
/*-----------------------Char input--------------------------------*/
char inputCheckChar();
/*-----------------------Name input--------------------------------*/
char *getName();
/*-----------------------Auxiliary functions-----------------------*/
void eat_Extra(void);
/*-----------------------flush in-----------------------*/
void flush_in();

#endif
